package com.example.db2;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.w3c.dom.Text;

import java.security.PublicKey;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class SIGNUP extends AppCompatActivity {

    RadioButton doctor;
    RadioButton lab;
    RadioButton hospital;
    static public Button signup;
    static TextView First_Name;
    static TextView Last_Name;
    static TextView Email;
    static TextView Phone_No;
    static TextView Password;
    static TextView Confirm_Password;
    static String str_FirstName,str_LastName,str_Email,str_PhoneNo,str_Password,str_ConfirmPassword;
    String url= "https://medico123.000webhostapp.com/signup.php";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        doctor = findViewById(R.id.Doctor);
        signup = findViewById(R.id.login);
        lab = findViewById(R.id.Laboratarian);
        hospital = findViewById(R.id.HospitalAdmin);
        First_Name = findViewById(R.id.fname);
        Last_Name = findViewById(R.id.lname);
        Email = findViewById(R.id.email);
        Phone_No = findViewById(R.id.pno);
        Password = findViewById(R.id.pass);
        Confirm_Password = findViewById(R.id.conpass);



        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SIGNUP();
            }
        });


//        doctor.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                Toast.makeText(SIGNUP.this, "Selected Doctor", Toast.LENGTH_SHORT).show();
//
//
//                signup.setText("next");
//
//            }
//        });


        doctor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                data();
                Intent intent = new Intent(SIGNUP.this, Doctor.class);
                startActivity(intent);

            }
        });

        lab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            data();
                Intent intent1 = new Intent(SIGNUP.this, Lab.class);
                startActivity(intent1);

            }
        });

        hospital.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

             data();
                Intent intent2 = new Intent(SIGNUP.this, Hospital.class);
                startActivity(intent2);

            }
        });
    }
        public void SIGNUP()
        {
            if(First_Name.getText().toString().equals(""))
            {
                Toast.makeText(this, "Enter Firstname", Toast.LENGTH_SHORT).show();
            }
            else if(Last_Name.getText().toString().equals("")){
                Toast.makeText(this, "Enter Last name", Toast.LENGTH_SHORT).show();
            }
            else if (Email.getText().toString().equals("")){
                Toast.makeText(this, "Enter Email", Toast.LENGTH_SHORT).show();
            }
            else if(Phone_No.getText().toString().equals(""))
            {
                Toast.makeText(this, "Enter Phone_No", Toast.LENGTH_SHORT).show();
            }
            else if(Password.getText().toString().equals(""))
            {
                Toast.makeText(this, "Enter Password", Toast.LENGTH_SHORT).show();
            }
            else if(Confirm_Password.getText().toString().equals(""))
            {
                Toast.makeText(this, "Enter Confirm Password", Toast.LENGTH_SHORT).show();
            }
            else
            {
                str_FirstName = First_Name.getText().toString().trim();
                str_LastName = Last_Name.getText().toString().trim();
                str_Email = Email.getText().toString().trim();
                str_PhoneNo = Phone_No.getText().toString().trim();
                str_Password = Password.getText().toString().trim();
                str_ConfirmPassword = Confirm_Password.getText().toString().trim();

                StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(SIGNUP.this, response, Toast.LENGTH_SHORT).show();
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(SIGNUP.this, error.getMessage().toString(), Toast.LENGTH_SHORT).show();
                    }
                }
                )
                {
                    @Nullable
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String,String> params = new HashMap<String, String>();
                        params.put("First_Name",str_FirstName);
                        params.put("Last_Name",str_LastName);
                        params.put("Email",str_Email);
                        params.put("Phone_No",str_PhoneNo);
                        params.put("Password",str_Password);
                        params.put("Confirm_Password",str_ConfirmPassword);
                        return params;

                    }
                };
                RequestQueue requestQueue = Volley.newRequestQueue(SIGNUP.this);
                requestQueue.add(request);

            }
        }

        public void data()
        {
            str_FirstName = First_Name.getText().toString().trim();
            str_LastName = Last_Name.getText().toString().trim();
            str_Email = Email.getText().toString().trim();
            str_PhoneNo = Phone_No.getText().toString().trim();
            str_Password = Password.getText().toString().trim();
            str_ConfirmPassword = Confirm_Password.getText().toString().trim();
        }
}