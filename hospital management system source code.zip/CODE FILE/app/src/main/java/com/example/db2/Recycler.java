package com.example.db2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Recycler extends AppCompatActivity {

    RecyclerView rcv;
    ListView listview;
    myadapter adapter;
    public static String spec;
    String url= "https://medico123.000webhostapp.com/retrieve.php";
    public static ArrayList<String> List = new ArrayList<>();
    String[] data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler);
        rcv=(RecyclerView)findViewById(R.id.rclview);
        rcv.setLayoutManager(new LinearLayoutManager(Recycler.this));
       // String arr[]={"Dermatologists","Ophthalmologists","Obstetrician","gynecologists","Cardiologists","Endocrinologists","Gastroenterologists"};
       //rcv.setAdapter(new myadapter(arr,Recycler.this));
    //   listview=findViewById(R.id.rclview);
        retrievedata();
     // rcv.setAdapter(adapter);
    }
    public void retrievedata()
    {
        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                 List.clear();
                try{

                    JSONObject jsonObject = new JSONObject(response);
                    String sucess = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if(sucess.equals("1")){


                        for(int i=0;i<jsonArray.length();i++){

                            JSONObject object = jsonArray.getJSONObject(i);

                            String Specialization = object.getString("Specialization");
                            List.add(Specialization);

                        }

                        data = new String[List.size()];
                        List.toArray(data);
                        rcv.setAdapter(new myadapter(data, Recycler.this));
                    }
                }
                catch (JSONException e){
                    e.printStackTrace();
                }



            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Recycler.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        );
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }

}