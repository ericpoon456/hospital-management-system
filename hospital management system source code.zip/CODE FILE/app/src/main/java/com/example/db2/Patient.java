package com.example.db2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Patient extends AppCompatActivity {

    CardView cd;
    CardView ad;
    CardView bd;
    CardView ed;
    CardView fd;
    CardView gd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient);

        cd=findViewById(R.id.patient_activity_health_forum_cv);
        ad=findViewById(R.id.patient_activity_lab_test_cv);
        bd=findViewById(R.id.patient_activity_disease_cv);
        ed=findViewById(R.id.patient_activity_hospital_cv);
        fd=findViewById(R.id.patient_activity_call_doctor_cv);
        gd=findViewById(R.id.patient_activity_book_appointment_cv);

        gd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a= new Intent(Patient.this,Recycler.class);
                startActivity(a);
            }
        });

//        ed.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent a= new Intent(Patient.this,Recycler.class);
//                startActivity(a);
//            }
//        });

        bd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent b=new Intent(Patient.this,search.class);
                startActivity(b);
            }
        });

        cd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a= new Intent(Patient.this,forum.class);
                startActivity(a);
            }
        });
    }
}









