package com.example.db2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;

public class Quote extends AppCompatActivity {

    RadioButton patient;
    RadioButton doctor; 
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quote);
        patient = findViewById(R.id.patient);
        doctor = findViewById(R.id.Doctor);
        button = findViewById(R.id.next);

        patient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                  button.setOnClickListener(new View.OnClickListener() {
                      @Override
                      public void onClick(View v) {
                          Intent b=new Intent(Quote.this,Patient.class);
                          startActivity(b);
                      }
                  });
            }
        });

        doctor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent b=new Intent(Quote.this,DActivity.class);
                        startActivity(b);
                    }
                });
            }
        });
    }
}