package com.example.db2;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.w3c.dom.Text;

import java.util.HashMap;
import java.util.Map;

public class Doctor extends AppCompatActivity {


    TextView CNIC;
    TextView Specialization;
    TextView Years_Of_Experience;
    TextView Works_At;
    TextView Doctor_Registration_Id;
    String str_CNIC, str_Specialization, str_Years_Of_Experience, str_Works_At, str_Doctor_Registration_Id;
    String url = "https://medico123.000webhostapp.com/doctorsignup.php";
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor);
        submit = findViewById(R.id.submit);
        CNIC = findViewById(R.id.cnic);
        Specialization = findViewById(R.id.spec);
        Years_Of_Experience = findViewById(R.id.years);
        Works_At = findViewById(R.id.worksat);
        Doctor_Registration_Id = findViewById(R.id.drid);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               doctorsignup();
            }
        });


    }

    public void doctorsignup() {
        str_CNIC = CNIC.getText().toString().trim();
        str_Specialization = Specialization.getText().toString().trim();
        str_Years_Of_Experience = Years_Of_Experience.getText().toString().trim();
        str_Works_At = Works_At.getText().toString().trim();
        str_Doctor_Registration_Id = Doctor_Registration_Id.getText().toString().trim();

        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(Doctor.this, response, Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Doctor.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        ) {

            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("First_Name",SIGNUP.str_FirstName);
                params.put("Last_Name",SIGNUP.str_LastName);
                params.put("Email",SIGNUP.str_Email);
                params.put("Phone_No",SIGNUP.str_PhoneNo);
                params.put("Password",SIGNUP.str_Password);
                params.put("Confirm_Password",SIGNUP.str_ConfirmPassword);
                params.put("CNIC",str_CNIC);
                params.put("Specialization", str_Specialization);
                params.put("Years_Of_Experience", str_Years_Of_Experience);
                params.put("Works_At", str_Works_At);
                params.put("Doctor_Registration_Id", str_Doctor_Registration_Id);
                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(Doctor.this);
        requestQueue.add(request);
    }
}