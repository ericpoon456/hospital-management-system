package com.example.db2;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputLayout;

import java.nio.channels.InterruptedByTimeoutException;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    TextInputLayout Email;
    Button button;
    TextInputLayout Password;
    RadioButton patient;
    RadioButton doctor;
    RadioButton hospital;
    RadioButton lab;

    String str_Email,str_Password;
    String url0= "https://medico123.000webhostapp.com/login.php";
    String url1= "https://medico123.000webhostapp.com/loginhospital.php";
    String url2= "https://medico123.000webhostapp.com/logindoctor.php";
    String url3= "https://medico123.000webhostapp.com/loginlab.php";

    String url;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Email=findViewById(R.id.login_email);
        Password=findViewById(R.id.login_password);

        TextView t = findViewById(R.id.reg);
        button = findViewById(R.id.login);
        patient=findViewById(R.id.patient);
        doctor=findViewById(R.id.Doctor);
        hospital=findViewById(R.id.HospitalAdmin);
        lab=findViewById(R.id.Laboratarian);
        patient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                url=url0;
            }
        });
        hospital.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                url=url1;
            }
        });
        doctor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                url=url2;
            }
        });
        lab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                url=url3;
            }
        });


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    login(url);
                 Intent z=new Intent(MainActivity.this,Quote.class);
                 startActivity(z);

            }
        });
        t.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {

                Intent a=new Intent(MainActivity.this,SIGNUP.class);
                startActivity(a);

            }
        });

    }
    public void login(String ur){

        str_Email = Email.getEditText().getText().toString().trim();
        str_Password = Password.getEditText().getText().toString().trim();

       // Toast.makeText(MainActivity.this, "Sucessful", Toast.LENGTH_SHORT).show();
        StringRequest request = new StringRequest(Request.Method.POST, ur, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(MainActivity.this, response, Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, error.getMessage().toString(), Toast.LENGTH_SHORT).show();
            }
        }
        )
        {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<String, String>();

                params.put("Email",str_Email);
                params.put("Password",str_Password);
                return params;

            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
        requestQueue.add(request);

    }
}
