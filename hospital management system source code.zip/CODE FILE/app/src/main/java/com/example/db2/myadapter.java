package com.example.db2;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.lang.reflect.Array;

public class myadapter extends RecyclerView.Adapter<myadapter.holder> {

     String data[];
     Context context;
    public myadapter (String[] data,Context context) {
        this.data = data;
        this.context=context;
    }

    @NonNull
    @Override
    public holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        View view= inflater.inflate(R.layout.singlerow,parent,false);
        return new holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull holder holder, @SuppressLint("RecyclerView") int position) {

       holder.t1.setText(data[position]);
       holder.c.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Recycler.spec = data[position];
              Intent a =new Intent(context,DoctorRecycler.class);
              context.startActivity(a);
           }
       });
    }

    @Override
    public int getItemCount() {
        return data.length;
    }


    class holder extends RecyclerView.ViewHolder
        {

            ImageView img1;
            TextView t1;
            CardView c;

            public holder(@NonNull View itemView) {
                super(itemView);
                img1=(ImageView)itemView.findViewById(R.id.img1);
                t1=(TextView)itemView.findViewById(R.id.t1);
                c=itemView.findViewById(R.id.cv);
            }
        }


}
