package com.example.db2;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class database extends SQLiteOpenHelper {
    private static final String dbname="register.db";
    public database(@Nullable Context context) {
        super(context, dbname,null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String q= "create table patient (pateint_id integer primary key autoincrement,First_Name text ,Last_Name text ,Email text,Password text,Confirm_Password text)";
        db.execSQL(q) ;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
  db.execSQL("drop table if exists patient");
  onCreate(db);
    }
    public boolean insert_data(String First_Name,String Last_Name,String Email,String Phone_No,String Password,String Confirm_Password,String tblName)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues c=new ContentValues();
        c.put("First_Name",First_Name);
        c.put("Last_Name",Last_Name);
        c.put("Email",Email);
        c.put("Phone_No",Phone_No);
        c.put("Password",Password);
        c.put("Confirm_Password",Confirm_Password);
        long r=db.insert(tblName,null,c);
        if(r==-1)
            return false;
        else
            return true;
    }
}
