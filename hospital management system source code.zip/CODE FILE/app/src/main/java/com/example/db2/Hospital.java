package com.example.db2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class Hospital extends AppCompatActivity {

    TextView Location;
    TextView Open_time;
    TextView Close_time;
    String str_Location,str_Open_time,str_Close_time;
    String url = "https://medico123.000webhostapp.com/Hospitalsignup.php";
    Button submit2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hospital);
        submit2=findViewById(R.id.submit2);
        Location=findViewById(R.id.location);
        Open_time=findViewById(R.id.otime);
        Close_time=findViewById(R.id.ctime);
        submit2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Hospitalsignup();
            }
        });

    }
    public void Hospitalsignup()
    {
        str_Location=Location.getText().toString().trim();
        str_Open_time=Open_time.getText().toString().trim();
        str_Close_time=Close_time.getText().toString().trim();
        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(Hospital.this, response, Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Hospital.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        ) {

            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("First_Name",SIGNUP.str_FirstName);
                params.put("Last_Name",SIGNUP.str_LastName);
                params.put("Email",SIGNUP.str_Email);
                params.put("Phone_No",SIGNUP.str_PhoneNo);
                params.put("Password",SIGNUP.str_Password);
                params.put("Confirm_Password",SIGNUP.str_ConfirmPassword);
                params.put("Location",str_Location);
                params.put("Open_time",str_Open_time);
                params.put("Close_time",str_Close_time);
                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(Hospital.this);
        requestQueue.add(request);
    }
    }
