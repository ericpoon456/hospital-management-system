
<?php
$servername = "localhost";
$username = "id18111891_medico12";
$database = "id18111891_medico";
$password = "T{dfm{GD5hs?clVx";

// Create connection
$connection = new mysqli($servername, $username, $password,$database);


    $Email = $_POST["Email"];
    $Password = $_POST["Password"];
     $sql=" SELECT *FROM Patient where Email = '$Email' and Password = '$Password'";
	$result = mysqli_query($connection,$sql);
	if($result->num_rows > 0){
	    echo "logged in successfully" ;
	}
	else
	{
	    echo "User not found";
	}


 ?>