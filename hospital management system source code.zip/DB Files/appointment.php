
<?php
$servername = "localhost";
$username = "id18111891_medico12";
$database = "id18111891_medico";
$password = "T{dfm{GD5hs?clVx";

// Create connection
$conn = new mysqli($servername, $username, $password,$database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// reciveing the data
$patient = $_POST["patientemail"];
$doctor = $_POST["doctoremail"];
$date = $_POST["date"];
$time =$_POST["time"];

$sql = "INSERT INTO Appointment(patientId,doctId,date,time) VALUES ('$patient','$doctor','$date','$time')";
$result = mysqli_query($conn,$sql);

if($result) {
echo "registered successfully";
}
else {
echo "some error occured";
}
?>