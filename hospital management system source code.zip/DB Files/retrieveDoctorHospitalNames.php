
<?php
$servername = "localhost";
$username = "id18111891_medico12";
$database = "id18111891_medico";
$password = "T{dfm{GD5hs?clVx";

// Create connection
$conn = new mysqli($servername, $username, $password,$database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$doc_email = $_POST["doc_email"];
	$result = array();
	$result['data'] = array();

	$select= "SELECT hospitalName from DoctorAtHospital where doctID = '$doc_email'";
	$responce = mysqli_query($conn,$select);
	
	while($row = mysqli_fetch_array($responce))
		{
		    $index['hospitalname'] = $row['0'];
			array_push($result['data'], $index);
		}
			
			$result["success"]="1";
			echo json_encode($result);
			mysqli_close($conn);
?>