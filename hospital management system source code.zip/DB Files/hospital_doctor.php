
<?php
$servername = "localhost";
$username = "id18111891_medico12";
$database = "id18111891_medico";
$password = "T{dfm{GD5hs?clVx";

// Create connection
$conn = new mysqli($servername, $username, $password,$database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// reciveing the data
$doctor = $_POST["doctor_email"];
$hospital_name = $_POST["hospital_name"];


$sql = "INSERT INTO DoctorAtHospital(doctId,hospitalName) VALUES ('$doctor','$hospital_name')";
$result = mysqli_query($conn,$sql);

if($result) {
echo "registered successfully";
}
else {
echo "some error occured";
}
?>