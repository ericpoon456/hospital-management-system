
<?php
$servername = "localhost";
$username = "id18111891_medico12";
$database = "id18111891_medico";
$password = "T{dfm{GD5hs?clVx";

// Create connection
$connection = new mysqli($servername, $username, $password,$database);


    $patient_id = $_POST["Patientemail"];

	$result = array();
	$result['data'] = array();
	$select= "SELECT doctID from Appointment where patientId = '$patient_id'";
	$responce = mysqli_query($connection,$select);
// 	$row = mysqli_fetch_array($responce);
// 	echo $row[0];
	
	while($row = mysqli_fetch_array($responce))
		{
		    
		   	$select= "SELECT First_Name,Last_Name,Phone_No from Doctor where First_Name = '$row[0]'";
		   	$responce1 = mysqli_query($connection,$select);
		   	$row1 = mysqli_fetch_array($responce1);
		   	
			$index['first_name']  = $row1['0'];
			$index['last_name']  = $row1['1'];
			$index['phone_number']  = $row1['2'];

			array_push($result['data'], $index);
		}
			
			$result["success"]="1";
			echo json_encode($result);
			mysqli_close($connection);

 ?>