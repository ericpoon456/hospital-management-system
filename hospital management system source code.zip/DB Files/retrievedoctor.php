
<?php
$servername = "localhost";
$username = "id18111891_medico12";
$database = "id18111891_medico";
$password = "T{dfm{GD5hs?clVx";

// Create connection
$connection = new mysqli($servername, $username, $password,$database);

  $spec = $_POST["spec"];
	$result = array();
	$result['data'] = array();
	$select= "SELECT First_Name,Last_Name from Doctor where Specialization = '$spec'";
	$responce = mysqli_query($connection,$select);
	
	while($row = mysqli_fetch_array($responce))
		{
			$index['First_Name']  = $row['0'];
				$index['Last_Name']  = $row['1'];
			
			array_push($result['data'], $index);
		}
			
			$result["success"]="1";
			echo json_encode($result);
			mysqli_close($connection);

 ?>