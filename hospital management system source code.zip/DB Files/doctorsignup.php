
<?php
$servername = "localhost";
$username = "id18111891_medico12";
$database = "id18111891_medico";
$password = "T{dfm{GD5hs?clVx";

// Create connection
$conn = new mysqli($servername, $username, $password,$database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// reciveing the data
$First_Name = $_POST["First_Name"];
$Last_Name = $_POST["Last_Name"];
$Email = $_POST["Email"];
$Phone_No =$_POST["Phone_No"];
$Password= $_POST["Password"];
$Confirm_Password = $_POST["Confirm_Password"];
$CNIC = $_POST["CNIC"];
$Specialization = $_POST["Specialization"];
$Years_Of_Experience = $_POST["Years_Of_Experience"];
$Works_At = $_POST["Works_At"];
$Doctor_Registration_Id = $_POST["Doctor_Registration_Id"];



$sql = "INSERT INTO Doctor(First_Name,Last_Name,Email,Phone_No,Password,Confirm_Password,CNIC,Specialization,Years_Of_Experience,Works_At,Doctor_Registration_Id) VALUES ('$First_Name','$Last_Name','$Email','$Phone_No','$Password','$Confirm_Password','$CNIC','$Specialization','$Years_Of_Experience','$Works_At','$Doctor_Registration_Id')";
$result = mysqli_query($conn,$sql);

if($result) {
echo "registered successfully";
}
else {
echo "some error occured";
}
?>
