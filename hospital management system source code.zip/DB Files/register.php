<?php
    $con=mysqli_connect("localhost","id18111891_deepak","7H/QdU$CPutu6v{Y","id18111891_medico123");
    $First_Name = $_POST["First_Name"];
    $Last_Name = $_POST["Last_Name"];
    $Email = $_POST["Email"]; 
    $Phone_No = $_POST["Phone_No"];  
    $Password = $_POST["Password"];
    $Confirm_Password = $_POST["Confirm_Password"]; 

$sql = "INSERT INTO Patient(First_Name,Last_Name,Email,Phone_No,Password,Confirm_Password) VALUES ('$First_Name','$Last_Name','$Email','$Phone_No','$Password','$Confirm_Password')";
    $result = mysqli_query($con,$sql);
    if($result)
       {
          echo "Sucessful";
    }
   else {
         echo "Error";
      }
?>




   

    
