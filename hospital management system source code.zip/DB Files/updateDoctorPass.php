
<?php
$servername = "localhost";
$username = "id18111891_medico12";
$database = "id18111891_medico";
$password = "T{dfm{GD5hs?clVx";

// Create connection
$conn = new mysqli($servername, $username, $password,$database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

    $oldPass = $_POST["old_pass"];
    $newPass = $_POST["new_pass"];
    $email = $_POST["email"];

	$select= "SELECT First_Name from Doctor where Email = '$email' and Password = '$oldPass'";
	$responce = mysqli_query($conn,$select);
	
	if($responce->num_rows > 0)
	{
	    $select= "UPDATE Doctor set Password = '$newPass' where Email = '$email'";
    //	$responce = mysqli_query($conn,$select);
    	if($conn->query($select) === TRUE)
    	{
    	    echo "updated";
    	}
	}
	mysqli_close($conn);
?>