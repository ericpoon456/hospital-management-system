
<?php
$servername = "localhost";
$username = "id18111891_medico12";
$database = "id18111891_medico";
$password = "T{dfm{GD5hs?clVx";

// Create connection
$conn = new mysqli($servername, $username, $password,$database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

	$result = array();
	$result['data'] = array();
	$select= "SELECT First_Name,Last_Name from Hospital";
	$responce = mysqli_query($conn,$select);
	
	while($row = mysqli_fetch_array($responce))
		{
			$index['firstname']  = $row['0'];
			$index['lastname']  = $row['1'];

			array_push($result['data'], $index);
		}
			
			$result["success"]="1";
			echo json_encode($result);
			mysqli_close($conn);
?>